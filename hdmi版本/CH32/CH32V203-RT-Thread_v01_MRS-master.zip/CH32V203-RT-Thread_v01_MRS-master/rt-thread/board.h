/*
 * File      : board.h
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-08-23     liYony       first version
 */

// <<< Use Configuration Wizard in Context Menu >>>
#ifndef __BOARD_H__
#define __BOARD_H__

#include <rtthread.h>
#include "ch32v20x.h"
#include "drv_gpio.h"
#define ch32v20x_PIN_NUMBERS   48
/* board configuration */
#if 0// define(USING_MAX_HEAP_SIZE)
#define SRAM_SIZE  20
#define SRAM_END (0x20000000 + SRAM_SIZE * 1024)



extern int _ebss,__stack_size;
#define HEAP_BEGIN  ((void *)&_ebss)
#define HEAP_END    (SRAM_END-__stack_size)
#else
extern int _ebss,_heap_end;
#define HEAP_BEGIN  ((void *)&_ebss)
#define HEAP_END    ((void *)&_heap_end)

#endif //USING_MAX_HEAP_SIZE
void rt_hw_board_init(void);

#endif /* __BOARD_H__ */
